// AppScript for Kitchen Appliance Website - Form Submission Handler
// Handles both GET (from file://) and POST requests
// Auto-creates sheet with headers if it doesn't exist

function doGet(e) {
  return handleFormSubmission(e);
}

function doPost(e) {
  return handleFormSubmission(e);
}

function handleFormSubmission(e) {
  try {
    // Get parameters from query string or POST body
    const params = e.queryString ? parseQueryString(e.queryString) : e.parameter;
    
    const name = params.name || '';
    const email = params.email || '';
    const phone = params.phone || '';
    
    // Validate inputs
    if (!name || !email || !phone) {
      return ContentService.createTextOutput(
        JSON.stringify({ success: false, message: 'Name, Email, and Phone are required' })
      ).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Get or create spreadsheet
    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = spreadsheet.getSheetByName('Responses');
    
    // Create sheet if it doesn't exist
    if (!sheet) {
      sheet = spreadsheet.insertSheet('Responses');
      // Add headers
      sheet.appendRow(['Timestamp', 'Name', 'Email', 'Phone']);
      // Format header row (bold)
      const headerRange = sheet.getRange(1, 1, 1, 4);
      headerRange.setFontWeight('bold');
      headerRange.setBackground('#E8E8E8');
    }
    
    // Get current time
    const timestamp = new Date().toLocaleString('en-IN', {
      timeZone: 'Asia/Kolkata',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
    
    // Append data to sheet
    sheet.appendRow([timestamp, name, email, phone]);
    
    return ContentService.createTextOutput(
      JSON.stringify({ success: true, message: 'Form submitted successfully' })
    ).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(
      JSON.stringify({ success: false, message: 'Error: ' + error.toString() })
    ).setMimeType(ContentService.MimeType.JSON);
  }
}

// Helper function to parse query string (for file:// protocol)
function parseQueryString(queryString) {
  const params = {};
  if (queryString) {
    const pairs = queryString.split('&');
    for (const pair of pairs) {
      const [key, value] = pair.split('=');
      params[decodeURIComponent(key)] = decodeURIComponent(value || '');
    }
  }
  return params;
}
