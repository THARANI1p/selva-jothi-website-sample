# Sri Selva Jothi Stores - Setup Instructions

## ✅ What's Included

- **index.html** - Complete responsive website with 3-field form, all buttons functional
- **Code.gs** - AppScript backend for Google Sheets integration

## 🔧 Setup Issues & Fixes

### Issue: 403 Forbidden Error on Form Submission

**Cause:** The AppScript web app deployment needs proper configuration.

### ✅ Solution: Redeploy AppScript with Correct Settings

1. **Open your Google Sheet**
   - Go to your Google Sheets file
   - Click **Extensions → Apps Script**

2. **Replace with New Code**
   - Delete everything in the editor
   - Paste the **Code.gs** content
   - **Ctrl+S** (or Cmd+S) to save

3. **Deploy as Web App** (IMPORTANT - This is likely the issue)
   - Click **Deploy** (top right, blue button)
   - Select **New deployment** (⚙️ icon)
   - **Type:** Select "Web app" (dropdown)
   - **Execute as:** Select your email/account
   - **Who has access:** Select "**Anyone**" (this is critical!)
   - Click **Deploy**

4. **Copy New Deployment URL**
   - A dialog will show: "Deployment successful"
   - Copy the URL (looks like: `https://script.google.com/macros/d/{ID}/userweb`)
   - This is different from your old URL!

5. **Update index.html**
   - Open **index.html** in a text editor
   - Find this line (around line 500+):
     ```javascript
     const SCRIPT_URL = 'https://script.google.com/macros/s/...';
     ```
   - Replace the entire URL with your new deployment URL
   - Save the file

---

## 📱 Features Now Working

✅ **Store Header**
- Sri Selva Jothi Stores branding
- Direct call button: **+91 94455 00532**
- WhatsApp quick access

✅ **All Buttons Functional**
- **Book a Service** → WhatsApp chat link
- **Enquire Now** → WhatsApp with product details
- **Call Us Now** → Telephone dial
- **WhatsApp Us** → WhatsApp chat

✅ **3-Field Form**
- Name, Email, Phone
- Submits to Google Sheets "Responses" tab
- Auto-creates sheet with headers if missing
- Timestamp automatically recorded
- Fallback to WhatsApp if submission fails

✅ **Fully Responsive Design**
- Desktop, Tablet, Mobile
- All Figma design elements included
- High-quality product images

---

## 📊 Google Sheets Integration

Once AppScript is working:

1. **Responses Sheet** - Automatically created with columns:
   - Timestamp (Asia/Kolkata timezone)
   - Name
   - Email
   - Phone

2. **Data Recording** - Each form submission:
   - Appends new row
   - Records submission time
   - Email notifications (optional - configure in Sheets)

---

## 🚀 Deployment Options

### Option 1: Local File (file://)
- Just open `index.html` in browser
- Forms will fallback to WhatsApp if AppScript not fully set up
- All buttons work (Call, WhatsApp)

### Option 2: Web Server
- Upload to any hosting (Netlify, Vercel, GitHub Pages, etc.)
- Professional appearance
- Forms work fully when AppScript is deployed

### Option 3: Google Drive
1. Upload `index.html` to Google Drive
2. Open file with Google Drive's HTML viewer
3. Share link with customers

---

## ✅ Verification Checklist

Before going live, test:

- [ ] Website loads (all images visible)
- [ ] Store name "Sri Selva Jothi Stores" visible in header
- [ ] Call button opens phone dialer with 94455 00532
- [ ] All WhatsApp buttons open WhatsApp chat
- [ ] Form submission (fill name/email/phone → submit)
- [ ] Check Google Sheet "Responses" tab for new rows
- [ ] Mobile responsive (test on phone)

---

## 🐛 Troubleshooting

**Q: Still getting 403 error?**
- Re-check: "Who has access" is set to "Anyone"
- Try "Deploy new version" instead of updating existing

**Q: Form submits but no Google Sheets entry?**
- Check your Google Sheet's sheet tab name is exactly "Responses"
- Ensure script has permission to edit your Google Sheet

**Q: WhatsApp links not opening?**
- Make sure to use on actual device (not just desktop browser)
- WhatsApp must be installed on device

**Q: Images not loading?**
- Images are hosted on Figma's CDN (7 days validity)
- If expired, download images from original Figma file and update URLs

---

## 📞 Contact Info in Website

- **WhatsApp:** 9445500532
- **Phone:** 9445500532 (same number)
- All buttons pre-configured with this number
- Easy to update if needed

---

## 📝 File Structure

```
├── index.html          (Main website - download this)
├── Code.gs            (Google Apps Script - copy into Apps Script editor)
└── INSTRUCTIONS.md    (This file)
```

---

## Questions?

If form still doesn't submit after following these steps:
1. Verify new deployment URL is in index.html
2. Test URL manually in browser: 
   `https://your-deployment-url?name=Test&email=test@test.com&phone=1234567890`
3. Check browser console (F12) for error messages
4. Ensure Google Sheets allows "Anyone" access

All buttons (Call, WhatsApp, Enquire) work immediately - forms will fallback gracefully if AppScript not configured.
